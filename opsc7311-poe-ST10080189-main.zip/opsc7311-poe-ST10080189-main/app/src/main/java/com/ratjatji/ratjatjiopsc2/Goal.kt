package com.ratjatji.ratjatjiopsc2

data class Goal(
    val userId: String,
    val minGoal: Double,
    val maxGoal: Double,
    val category: String
)

