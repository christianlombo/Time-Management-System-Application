package com.ratjatji.ratjatjiopsc2


import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CategoriesList : AppCompatActivity() {

    private lateinit var categories: MutableList<String>
    private lateinit var categoriesTextView: TextView
//    private lateinit val btnAddGoal: Button
//    private lateinit val btnAddTimeSheet: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_categories_list)

        categories = intent.getStringArrayListExtra("categories")?.toMutableList() ?: mutableListOf()
        if (categories.isNotEmpty()) {
            Toast.makeText(this, "Received ${categories.size} categories", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "No categories received", Toast.LENGTH_SHORT).show()
        }

        // Load categories from SharedPreferences
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val categoriesSet = sharedPreferences.getStringSet("categories", setOf()) ?: setOf()
        categories.addAll(categoriesSet)

        // Find the TextView in the layout
        categoriesTextView = findViewById(R.id.tvCategoryTasks)

        // Call a function to display the categories
        displayCategories()

        val btnCreateCategory = findViewById<Button>(R.id.btnCreateCategory)
        var btnAddGoal = findViewById<Button>(R.id.btnAddGoal)
        var btnAddTimeSheet = findViewById<Button>(R.id.btnAddTimeSheet)

        btnCreateCategory.setOnClickListener {
            val intent = Intent(this, CatActivity::class.java)
            startActivity(intent)
        }
        btnAddGoal.setOnClickListener {
            val intent = Intent(this, DailyGoals::class.java)
            startActivity(intent)
        }
        btnAddTimeSheet.setOnClickListener {
            val intent = Intent(this, TimeSheetEntries::class.java)
            startActivity(intent)
        }

    }

    private fun displayCategories() {
        // Concatenate all categories into a single string
        val categoriesString = buildString {
            categories.forEach { category ->
                append("* $category\n")
            }
        }

        // Set the concatenated string to the TextView
        categoriesTextView.text = categoriesString
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.logout -> {
                val intent = Intent(this@CategoriesList, Login::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.communications -> {
                val intent = Intent(this@CategoriesList, MainActivity::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.timeEntry -> {
                val intent = Intent(this@CategoriesList, TimeSheetEntries::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.dailyGoal -> {
                val intent = Intent(this@CategoriesList, DailyGoals::class.java)
                startActivity(intent)
                finish()
                true
            }

            R.id.back -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}