package com.ratjatji.ratjatjiopsc2

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ratjatji.ratjatjiopsc2.TimeSheetEntry
import com.ratjatji.ratjatjiopsc2.databinding.ItemEntryBinding

class rvTimeSheetAdapter(private val timeSheetList: List<TimeSheetEntry>) :
    RecyclerView.Adapter<rvTimeSheetAdapter.TimeSheetViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimeSheetViewHolder {
        val binding = ItemEntryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TimeSheetViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TimeSheetViewHolder, position: Int) {
        val entry = timeSheetList[position]
        holder.bind(entry)
    }

    override fun getItemCount(): Int = timeSheetList.size

    class TimeSheetViewHolder(private val binding: ItemEntryBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(entry: TimeSheetEntry) {
            binding.textViewTitle.text = entry.title
            binding.textViewCategory.text = entry.category
            binding.textViewDateTime.text = entry.date
            binding.textViewDescription.text = entry.description
            binding.textViewStartTime.text = entry.startTime
            binding.textViewDuration.text = entry.timeEntryDuration.toString()
            // Uncomment and set imageUri if it is available
            // binding.img.setImageURI(entry.imageUri)
        }
    }
}
