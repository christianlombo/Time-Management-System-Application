package com.ratjatji.ratjatjiopsc2

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import com.ratjatji.ratjatjiopsc2.Goal // Ensure this import statement is present

class CatActivity : AppCompatActivity() {
    private val categories = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_activty)

        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val categoriesSet = sharedPreferences.getStringSet("categories", setOf()) ?: setOf()
        categories.addAll(categoriesSet)

        val etCategoryName = findViewById<EditText>(R.id.etCategoryName)
        val btnAddCategory = findViewById<Button>(R.id.btAddCategory)

        btnAddCategory.setOnClickListener {
            val categoryName = etCategoryName.text.toString().trim()
            if (categoryName.isNotEmpty()) {
                categories.add(categoryName)
                etCategoryName.text.clear()

                // Save updated categories to SharedPreferences
                sharedPreferences.edit().putStringSet("categories", categories.toSet()).apply()

                // Start TimeSheetEntries activity and pass categories
                val timeSheetEntriesIntent = Intent(this, TimeSheetEntries::class.java)
                timeSheetEntriesIntent.putStringArrayListExtra("categories", ArrayList(categories))
                startActivity(timeSheetEntriesIntent)
            }
        }

        val btnViewCategories = findViewById<Button>(R.id.btnViewCategories)
        btnViewCategories.setOnClickListener {
            val intent = Intent(this, CategoriesList::class.java)
            intent.putStringArrayListExtra("categories", ArrayList(categories))
            startActivity(intent)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        if (menu != null) {
            menuInflater.inflate(R.menu.menu, menu)
            return true
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.logout -> {
                val intent = Intent(this@CatActivity, Login::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.communications -> {
                val intent = Intent(this@CatActivity, MainActivity::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.timeEntry -> {
                val intent = Intent(this@CatActivity, TimeSheetEntries::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.dailyGoal -> {
                val intent = Intent(this@CatActivity, DailyGoals::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.back -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
