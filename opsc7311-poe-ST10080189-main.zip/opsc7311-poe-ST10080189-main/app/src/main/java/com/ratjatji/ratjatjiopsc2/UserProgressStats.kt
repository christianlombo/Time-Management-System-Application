package com.ratjatji.ratjatjiopsc2
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ratjatji.ratjatjiopsc2.databinding.ActivityUserProgressStatsBinding

class UserProgressStats : AppCompatActivity() {

    private var _binding: ActivityUserProgressStatsBinding? = null
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityUserProgressStatsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.apply {
            btnGoalChart.setOnClickListener {
                startActivity(Intent(this@UserProgressStats, UserChartActivity::class.java))
            }
            btnDurationChart.setOnClickListener{
                startActivity(Intent(this@UserProgressStats,DurationChart::class.java))
            }

        }

    }
    override fun onDestroy() {
        super.onDestroy()
        _binding=null}
}