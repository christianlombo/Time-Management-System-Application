package com.ratjatji.ratjatjiopsc2
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

import android.graphics.Color
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import com.ratjatji.ratjatjiopsc2.R

class UserChartActivity : AppCompatActivity() {
    private val xValues = listOf("Read min", "Read max", "Implement min", "Implement max")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_chart)

        val barChart: BarChart = findViewById(R.id.chart)
        barChart.axisRight.isEnabled = false

        val goals = arrayListOf<BarEntry>()
        goals.add(BarEntry(0f, 2f))
        goals.add(BarEntry(1f, 5f))
        goals.add(BarEntry(2f, 3f))
        goals.add(BarEntry(3f, 7f))

        val yAxis: YAxis = barChart.axisLeft
        yAxis.axisMinimum = 0f
        yAxis.axisMaximum = 12f
        yAxis.axisLineWidth = 2f
        yAxis.axisLineColor = Color.BLACK
        yAxis.setLabelCount(10, true)

        val dataSet = BarDataSet(goals, "Goals")
        dataSet.colors = ColorTemplate.MATERIAL_COLORS.toList()

        val barData = BarData(dataSet)
        barChart.data = barData

        barChart.description.isEnabled = false
        barChart.invalidate()

        val xAxis = barChart.xAxis
        xAxis.valueFormatter = IndexAxisValueFormatter(xValues)
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.granularity = 1f
        xAxis.isGranularityEnabled=true
    }
}