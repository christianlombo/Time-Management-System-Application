package com.ratjatji.ratjatjiopsc2


import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson

class DisplayAllGoals : AppCompatActivity() {
    private lateinit var goalAdapter: GoalsAdapter
    private val goals = mutableListOf<Goal>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_all_goals)

        val AddGoals = findViewById<Button>(R.id.btnAddGoal)
        AddGoals.setOnClickListener {
            val intent = Intent(this, DailyGoals::class.java)
            startActivity(intent)
        }

        // Initialize RecyclerView and adapter
        val recyclerView = findViewById<RecyclerView>(R.id.goalsRecyclerView)
        goalAdapter = GoalsAdapter(goals)
        recyclerView.adapter = goalAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Load goals from SharedPreferences
        loadGoals()

    }

    // Function to load goals from SharedPreferences
    private fun loadGoals() {
        val sharedPreferences: SharedPreferences = getSharedPreferences("goals", MODE_PRIVATE)
        val goalsString: String? = sharedPreferences.getString("goals", null)

        goalsString?.let { string ->
            val gson = Gson()
            val loadedGoals = gson.fromJson(string, Array<Goal>::class.java)
            goals.clear()
            goals.addAll(loadedGoals)
            goalAdapter.notifyDataSetChanged()
        }
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        if (menu != null) {
            menuInflater.inflate(R.menu.menu, menu)
            return true
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.logout -> {
                val intent = Intent(this@DisplayAllGoals, Login::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.communications -> {
                val intent = Intent(this@DisplayAllGoals, MainActivity::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.timeEntry -> {
                val intent = Intent(this@DisplayAllGoals, TimeSheetEntries::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.dailyGoal -> {
                val intent = Intent(this@DisplayAllGoals, DailyGoals::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.back -> {
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

}
