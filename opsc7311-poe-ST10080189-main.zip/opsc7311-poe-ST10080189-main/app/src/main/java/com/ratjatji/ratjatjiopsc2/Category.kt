package com.ratjatji.ratjatjiopsc2

data class Category (
    val name:String)