package com.ratjatji.ratjatjiopsc2

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.utils.ColorTemplate
import com.ratjatji.ratjatjiopsc2.R.*
import com.ratjatji.ratjatjiopsc2.R.id.chart2

class DurationChart : AppCompatActivity() {
    private val xValue = listOf("Read min", "Read max", "Implement min", "Implement max")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(layout.activity_duration_chart)

        val barChart2: BarChart = findViewById(R.id.chart2)
        barChart2.axisRight.isEnabled = false

        val totDuration = arrayListOf<BarEntry>()
        totDuration.add(BarEntry(0f, 8f))
        totDuration.add(BarEntry(1f, 5f))
        totDuration.add(BarEntry(2f, 7f))
        totDuration.add(BarEntry(3f, 4.5f))


        val yAxis1: YAxis = barChart2.axisLeft
        yAxis1.axisMinimum = 0f
        yAxis1.axisMaximum = 12f
        yAxis1.axisLineWidth = 2f
        yAxis1.axisLineColor = Color.BLACK
        yAxis1.setLabelCount(10, true)

        val dataSet2 = BarDataSet(totDuration, "Days")
        dataSet2.colors = ColorTemplate.MATERIAL_COLORS.toList()

        val barData = BarData(dataSet2)
        barChart2.data = barData

        barChart2.description.isEnabled = false
        barChart2.invalidate()

        val xAxis1 = barChart2.xAxis
        xAxis1.valueFormatter = IndexAxisValueFormatter(xValue)
        xAxis1.position = XAxis.XAxisPosition.BOTTOM
        xAxis1.granularity = 1f
        xAxis1.isGranularityEnabled=true

    }
}
