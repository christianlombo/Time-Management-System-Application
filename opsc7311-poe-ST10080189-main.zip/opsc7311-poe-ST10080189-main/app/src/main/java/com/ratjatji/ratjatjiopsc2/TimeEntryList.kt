package com.ratjatji.ratjatjiopsc2

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.ratjatji.ratjatjiopsc2.databinding.ActivityTimeEntryListBinding

class TimeEntryList : AppCompatActivity() {

    private lateinit var mAuth: FirebaseAuth
    private lateinit var mDbRef: DatabaseReference
    private lateinit var binding: ActivityTimeEntryListBinding
    private lateinit var timeSheetEntriesList: ArrayList<TimeSheetEntry>
    private lateinit var adapter: rvTimeSheetAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTimeEntryListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mAuth = FirebaseAuth.getInstance()
        mDbRef = FirebaseDatabase.getInstance().reference
        timeSheetEntriesList = arrayListOf()
        adapter = rvTimeSheetAdapter(timeSheetEntriesList)

        setupRecyclerView()
        fetchUserInfo()
    }

    private fun setupRecyclerView() {
        binding.RCLdisplayAllEntry.layoutManager = LinearLayoutManager(this)
        binding.RCLdisplayAllEntry.adapter = adapter
    }

    private fun fetchUserInfo() {
        val currentUser = mAuth.currentUser
        currentUser?.let {
            val userId = it.uid
            mDbRef.child("users").child(userId).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val user = snapshot.getValue(User::class.java)
                    user?.let {
                        binding.tvUserInformation.text = "Welcome, ${it.name}"
                        fetchTimeSheetEntries(userId)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@TimeEntryList, "Failed to load user info", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }
    private fun fetchTimeSheetEntries(userId: String) {
        mDbRef.child("TimeSheetEntries").child(userId).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                timeSheetEntriesList.clear()
                if (snapshot.exists()) {
                    for (entrySnapshot in snapshot.children) {
                        val entry = entrySnapshot.getValue(TimeSheetEntry::class.java)
                        entry?.let {
                            timeSheetEntriesList.add(it)
                            Log.d("TimeEntryList", "Entry added: ${it.title}") // Log added
                        }
                    }
                    adapter.notifyDataSetChanged()
                } else {
                    Log.d("TimeEntryList", "No data found for user: $userId") // Log added
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@TimeEntryList, "Failed to load time sheet entries", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
