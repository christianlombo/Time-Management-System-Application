package com.ratjatji.ratjatjiopsc2

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Invoice : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var invoiceAdapter: InvoiceAdapter
    private lateinit var totalTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_invoice)

        recyclerView = findViewById(R.id.recyclerViewInvoice)
        recyclerView.layoutManager = LinearLayoutManager(this)

        totalTextView = findViewById(R.id.totalTextView)
        val testData = listOf(
            TimeSheetEntry("8hZS26LN4QcgWtuaKcpkotbN0pG2", "Machine learning", "testing models", "Testing predictive models on Kaggle", "13:00", 1.0, "2024-6-5", "content://media/external_primary/images/media/1000014075"),
            TimeSheetEntry("8hZS26LN4QcgWtuaKcpkotbN0pG2", "Machine learning", "training predictive model", "training titanic data set", "09:00", 3.0, "2024-6-5", null)
        )

        val userMap = mapOf(
            "8hZS26LN4QcgWtuaKcpkotbN0pG2" to User("Attie Malatji",   "attie@gmail.com", "8hZS26LN4QcgWtuaKcpkotbN0pG2")
        )
        invoiceAdapter = InvoiceAdapter(testData, userMap)
        recyclerView.adapter = invoiceAdapter

        val total = invoiceAdapter.calculateTotal()
        totalTextView.text = "Total: R$total"
    }
}