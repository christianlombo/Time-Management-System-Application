package com.ratjatji.ratjatjiopsc2


import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class UserDashBoard : AppCompatActivity() {
    private lateinit var mAuth: FirebaseAuth
    private lateinit var mDbRef: DatabaseReference
    private lateinit var tvUserInformation: TextView
    private lateinit var userList: ArrayList<User>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Toast.makeText(this,"Use the menu option in the top right to navigate through the app", Toast.LENGTH_LONG).show()
        setContentView(R.layout.activity_user_dash_board)
        mAuth = FirebaseAuth.getInstance()
        mDbRef = FirebaseDatabase.getInstance().getReference()
        userList = ArrayList()

        //var btnCategories = findViewById<Button>(R.id.btnCategories)
        var btnTimesheet = findViewById<Button>(R.id.btnTimesheet)
        var btnGoals = findViewById<Button>(R.id.btnGoals)
        var btnCommunication = findViewById<Button>(R.id.btnCommunication)
        var btnLogOut = findViewById<Button>(R.id.btnLogOut)
        var btnInvoice = findViewById<Button>(R.id.btnInvoice)
        var btnGraph = findViewById<Button>(R.id.btnGraph)

        // Get reference to the TextView
        val tvUserInformation = findViewById<TextView>(R.id.tvUserInformation)

        // Check if user is signed in
        val currentUser = mAuth.currentUser
        if (currentUser != null) {
            // User is signed in, fetch user's name from Firebase Database
            mDbRef.child("user").child(currentUser.uid).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val user = snapshot.getValue(User::class.java)
                    val userName = user?.name
                    if (userName != null) {
                        // Set the welcome message with the user's name
                        tvUserInformation.text = "Welcome, $userName"
                    }
                }
                    override fun onCancelled(error: DatabaseError) {
                    // Handle error if needed
                }
            })
        } else {
            // User is not signed in, display default message
            tvUserInformation.text = "Welcome"
        }

        btnInvoice.setOnClickListener {
            startActivity(Intent(this, Invoice::class.java))
        }
        btnGraph.setOnClickListener {
            startActivity(Intent(this, UserProgressStats::class.java))
        }
        btnTimesheet.setOnClickListener {
            startActivity(Intent(this, TimeSheetEntries::class.java))
        }
        btnGoals.setOnClickListener {
            startActivity(Intent(this, DailyGoals::class.java))
        }
        btnCommunication.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
        btnLogOut.setOnClickListener {
            startActivity(Intent(this, Login::class.java))
        }
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    fun onDataChange(snapshot: DataSnapshot) {
        userList.clear()
        val currentUser = mAuth.currentUser

        // Check if the current user is signed in
        if (currentUser != null) {
            for (postSnapshot in snapshot.children) {
                val user = postSnapshot.getValue(User::class.java)
                // Check if the user's UID matches the current user's UID
                if (user?.uid == currentUser.uid) {
                    // Display the welcome message with the user's name
                    val userName = user.name
                    if (userName != null) {
                        tvUserInformation.text = "Welcome, $userName"
                    } else {
                        // If user name is null, display a default message
                        tvUserInformation.text = "Welcome"
                    }
                    break // Exit the loop once the current user is found
                }
            }
        } else {
            // If no user is signed in, display a default message
            tvUserInformation.text = "Welcome"
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.logout -> {
                val intent = Intent(this@UserDashBoard, Login::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.communications -> {
                val intent = Intent(this@UserDashBoard, MainActivity::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.timeEntry -> {
                val intent = Intent(this@UserDashBoard, TimeSheetEntries::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.dailyGoal -> {
                val intent = Intent(this@UserDashBoard, DailyGoals::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.back -> {
                val intent = Intent(this@UserDashBoard, CatActivity::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.invoice -> {
                val intent = Intent(this@UserDashBoard, Invoice::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.graph -> {
                val intent = Intent(this@UserDashBoard, UserProgressStats::class.java)
                startActivity(intent)
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
