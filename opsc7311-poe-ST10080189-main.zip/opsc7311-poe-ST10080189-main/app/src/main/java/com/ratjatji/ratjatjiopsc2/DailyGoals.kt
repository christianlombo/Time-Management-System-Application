package com.ratjatji.ratjatjiopsc2

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class DailyGoals : AppCompatActivity() {
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth
    private lateinit var goalsAdapter: GoalsAdapter
    private val goalsList = mutableListOf<Goal>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_daily_goals)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        val btSaveGoals = findViewById<Button>(R.id.btSaveGoals)
        val etCategory = findViewById<EditText>(R.id.etCategory)
        //val btDisplayAllGoals = findViewById<Button>(R.id.btDisplayGoals)
        val rvGoals = findViewById<RecyclerView>(R.id.RCLdisplayAllGoals)

        // Initialize RecyclerView
        goalsAdapter = GoalsAdapter(goalsList)
        rvGoals.layoutManager = LinearLayoutManager(this)
        rvGoals.adapter = goalsAdapter

        btSaveGoals.setOnClickListener {
            val minGoal = findViewById<EditText>(R.id.etMinGoal).text.toString().toDoubleOrNull()
            val maxGoal = findViewById<EditText>(R.id.etMaxGoal).text.toString().toDoubleOrNull()

            if (minGoal != null && maxGoal != null && minGoal <= maxGoal) {
                val selectedCategory = etCategory.text.toString()
                val userId = auth.currentUser?.uid

                if (userId != null) {
                    val newGoal = Goal(userId, minGoal, maxGoal, selectedCategory)
                    saveGoal(newGoal)
                    Toast.makeText(this, "Goal saved successfully!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Goal not saved!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter both a minimum and maximum goal.", Toast.LENGTH_SHORT).show()
            }
        }

       /* btDisplayAllGoals.setOnClickListener {
            startActivity(Intent(this, DisplayAllGoals::class.java))
        }*/
    }

    private fun saveGoal(goal: Goal) {
        val userId = goal.userId
        database.child("Goals").child(userId).push().setValue(goal).addOnSuccessListener {
            // Successfully saved the goal
            goalsList.add(goal)
            goalsAdapter.notifyDataSetChanged()
            findViewById<EditText>(R.id.etMinGoal).text.clear()
            findViewById<EditText>(R.id.etMaxGoal).text.clear()
            findViewById<EditText>(R.id.etCategory).text.clear()
        }.addOnFailureListener {
            // Handle failure
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.logout -> {
                val intent = Intent(this@DailyGoals, Login::class.java)
                startActivity(intent)
                finish()
                true
            }

            R.id.communications -> {
                val intent = Intent(this@DailyGoals, MainActivity::class.java)
                startActivity(intent)
                finish()
                true
            }

            R.id.timeEntry -> {
                val intent = Intent(this@DailyGoals, TimeSheetEntries::class.java)
                startActivity(intent)
                finish()
                true
            }

            R.id.dailyGoal -> {
                val intent = Intent(this@DailyGoals, DailyGoals::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.back -> {
                onBackPressed()
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }
}
