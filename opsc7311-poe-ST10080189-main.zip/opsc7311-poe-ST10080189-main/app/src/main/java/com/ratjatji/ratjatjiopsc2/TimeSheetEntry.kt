package com.ratjatji.ratjatjiopsc2
data class TimeSheetEntry(
    val uploaderUid: String,
    val title: String,
    val category: String,
    val description: String,
    val startTime: String,
    val timeEntryDuration: Double,
    val date: String,
    val imageUrl: String?
)
