package com.ratjatji.ratjatjiopsc2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class InvoiceAdapter(private val entries: List<TimeSheetEntry>, private val userMap: Map<String, User>) : RecyclerView.Adapter<InvoiceAdapter.InvoiceViewHolder>() {

    private val hourlyRate = 150.0

    class InvoiceViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val nameTextView: TextView = view.findViewById(R.id.nameTextView)
        val titleTextView: TextView = view.findViewById(R.id.titleTextView)
        val categoryTextView: TextView = view.findViewById(R.id.categoryTextView)
        val durationTextView: TextView = view.findViewById(R.id.durationTextView)
        val hourlyRateTextView: TextView = view.findViewById(R.id.hourlyRateTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InvoiceViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.invoice_item, parent, false)
        return InvoiceViewHolder(view)
    }

    override fun onBindViewHolder(holder: InvoiceViewHolder, position: Int) {
        val entry = entries[position]
        val user = userMap[entry.uploaderUid]
        holder.nameTextView.text = user?.name ?: "Unknown"
        holder.titleTextView.text = entry.title
        holder.categoryTextView.text = entry.category
        holder.durationTextView.text = entry.timeEntryDuration.toString()
        holder.hourlyRateTextView.text = "R$hourlyRate/hr"
    }

    override fun getItemCount(): Int = entries.size

    fun calculateTotal(): Double {
        return entries.sumOf { it.timeEntryDuration * hourlyRate }
    }
}