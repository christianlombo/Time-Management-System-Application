package com.ratjatji.ratjatjiopsc2;

import android.app.Activity;

public class activity_goal_item extends Activity {
}
