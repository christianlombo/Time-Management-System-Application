package com.ratjatji.ratjatjiopsc2
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.ratjatji.ratjatjiopsc2.databinding.ActivityTimeSheetEntriesBinding
import java.util.Calendar

class TimeSheetEntries : AppCompatActivity() {
    private lateinit var etDate: EditText
    private lateinit var ivImage: ImageView
    private lateinit var recyclerView: RecyclerView
    private lateinit var entryAdapter: EntryAdapter
    private var imageUri: Uri? = null
    private val entriesList = ArrayList<TimeSheetEntry>()

    private lateinit var binding: ActivityTimeSheetEntriesBinding
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth

    companion object {
        private const val REQUEST_IMAGE_PICK = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTimeSheetEntriesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        etDate = findViewById(R.id.etDate)
        ivImage = findViewById(R.id.ivImage)
        recyclerView = findViewById(R.id.RCLdisplayAllEntry)
        recyclerView.layoutManager = LinearLayoutManager(this)
        entryAdapter = EntryAdapter(entriesList)
        recyclerView.adapter = entryAdapter

        val btnUploadImage = findViewById<Button>(R.id.btnUploadImage)
        btnUploadImage.setOnClickListener {
            onUploadImageClicked(it)
        }

        val btnSaveEntry = findViewById<Button>(R.id.btnSaveEntry)
        btnSaveEntry.setOnClickListener {
            onSaveEntryClicked()
        }

        val btnShowAllEntries = findViewById<Button>(R.id.btnShowAllEntries)
        btnShowAllEntries.setOnClickListener {
            startActivity(Intent(this@TimeSheetEntries, TimeEntryList::class.java))
        }
        val btnShowInvoice = findViewById<Button>(R.id.btnShowInvoice)
        btnShowInvoice.setOnClickListener {
            startActivity(Intent(this@TimeSheetEntries, Invoice::class.java))
        }

    }

    fun showDatePickerDialog(v: View) {
        val editText = v as EditText // Assuming the caller is an EditText
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, dayOfMonth ->
                val selectedDate = "$selectedYear-${selectedMonth + 1}-$dayOfMonth"
                editText.setText(selectedDate)
            },
            year,
            month,
            dayOfMonth
        )

        datePickerDialog.show()
    }

    fun onUploadImageClicked(view: View) {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, REQUEST_IMAGE_PICK)
    }

    private fun onSaveEntryClicked() {
        val uploaderUid = auth.currentUser?.uid
        val title = binding.etTitle.text.toString()
        val category = binding.etCategory.text.toString()
        val description = binding.etDescription.text.toString()
        val startTime = binding.etStartTime.text.toString()
        val timeEntryDurationString = binding.etTimeSheetDuration.text.toString()
        val date = binding.etDate.text.toString()

        // Convert timeEntryDuration to double
        val timeEntryDuration: Double = timeEntryDurationString.toDoubleOrNull() ?: 0.0

        if (uploaderUid != null) {
            // Create a new TimeSheetEntry object
            val timeSheetEntry = TimeSheetEntry(uploaderUid, title, category, description, startTime, timeEntryDuration, date, imageUri?.toString())

            // Save to the database
            database.child("TimeSheetEntries").child(uploaderUid).push()
                .setValue(timeSheetEntry).addOnSuccessListener {
                    // Save to the local list
                    entriesList.add(timeSheetEntry)
                    entryAdapter.notifyDataSetChanged()

                    // Clear input fields
                    clearInputFields()
                    Toast.makeText(this, "Time entry added successfully", Toast.LENGTH_SHORT).show()
                }.addOnFailureListener { e ->
                    Log.e("TimeSheetEntries", "Failed to add time entry", e)
                    Toast.makeText(this, "Failed to add time entry", Toast.LENGTH_SHORT).show()
                }
        } else {
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearInputFields() {
        binding.etTitle.text.clear()
        binding.etCategory.text.clear()
        binding.etDescription.text.clear()
        binding.etStartTime.text.clear()
        binding.etTimeSheetDuration.text?.clear()
        binding.etDate.text.clear()
        ivImage.setImageResource(0)
        imageUri = null
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_PICK && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                ivImage.setImageURI(uri)
                imageUri = uri
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        if (menu != null) {
            menuInflater.inflate(R.menu.menu, menu)
            return true
        }
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.logout -> {
                val intent = Intent(this@TimeSheetEntries, Login::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.communications -> {
                val intent = Intent(this@TimeSheetEntries, MainActivity::class.java)
                startActivity(intent)
                finish()
                true
            }
            R.id.timeEntry -> {
                val intent = Intent(this@TimeSheetEntries, TimeSheetEntries::class.java)
                startActivity(intent)
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
