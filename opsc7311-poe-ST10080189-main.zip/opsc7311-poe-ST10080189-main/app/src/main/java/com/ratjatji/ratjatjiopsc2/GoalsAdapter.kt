package com.ratjatji.ratjatjiopsc2

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class GoalsAdapter(private val goalsList: List<Goal>) : RecyclerView.Adapter<GoalsAdapter.GoalViewHolder>() {

    class GoalViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val minGoalTextView: TextView = itemView.findViewById(R.id.minGoalTextView)
        val maxGoalTextView: TextView = itemView.findViewById(R.id.maxGoalTextView)
        val categoryTextView: TextView = itemView.findViewById(R.id.categoryTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GoalViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_goal_item, parent, false)
        return GoalViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: GoalViewHolder, position: Int) {
        val goal = goalsList[position]
        holder.minGoalTextView.text = "Min Goal: ${goal.minGoal} hrs"
        holder.maxGoalTextView.text = "Max Goal: ${goal.maxGoal} hrs"
        holder.categoryTextView.text = "Category: ${goal.category}"
    }

    override fun getItemCount(): Int {
        return goalsList.size
    }
}
