package com.ratjatji.ratjatjiopsc2
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EntryAdapter(private val entriesList: List<TimeSheetEntry>) :
    RecyclerView.Adapter<EntryAdapter.EntryViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntryViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_entry, parent, false)
        return EntryViewHolder(view)
    }

    override fun onBindViewHolder(holder: EntryViewHolder, position: Int) {
        val entry = entriesList[position]
        holder.title.text = entry.title
        holder.category.text = entry.category
        holder.dateTime.text = entry.date
        holder.description.text = entry.description
        holder.duration.text = entry.timeEntryDuration.toString()
        holder.startTime.text = entry.startTime
        entry.imageUrl?.let {
            holder.image.setImageURI(Uri.parse(it))
        }
    }

    override fun getItemCount() = entriesList.size

    class EntryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val title: TextView = itemView.findViewById(R.id.textViewTitle)
        val category: TextView = itemView.findViewById(R.id.textViewCategory)
        val dateTime: TextView = itemView.findViewById(R.id.textViewDateTime)
        val description: TextView = itemView.findViewById(R.id.textViewDescription)
        val duration: TextView = itemView.findViewById(R.id.textViewDuration)
        val startTime: TextView = itemView.findViewById(R.id.textViewStartTime)
        val image: ImageView = itemView.findViewById(R.id.imageViewEntry)
    }
}
